// API URL
const API_URL = "https://api.restful-api.dev/objects";

// Local storage key
const STORAGE_KEY = "konohaNinjaRecords";

// Records
let records = [];

// HTML elements
const form = document.getElementById("recordForm");
const recordId = document.getElementById("recordId");
const nameInput = document.getElementById("name");
const emailInput = document.getElementById("email");
const saveBtn = document.getElementById("saveBtn");
const cancelBtn = document.getElementById("cancelBtn");
const refreshBtn = document.getElementById("refreshBtn");
const recordTable = document.getElementById("recordTable");
const status = document.getElementById("status");
const loading = document.getElementById("loading");

// Edit modal elements
const editModal = document.getElementById("editModal");
const editForm = document.getElementById("editForm");
const editId = document.getElementById("editId");
const editName = document.getElementById("editName");
const editEmail = document.getElementById("editEmail");
const closeModal = document.getElementById("closeModal");
const cancelEdit = document.getElementById("cancelEdit");

// Show status
function showStatus(message, type) {

    status.textContent = message;

    status.className = `status ${type}`;
}

// Hide status
function hideStatus() {

    status.textContent = "";

    status.className = "status hidden";
}

// Loading
function setLoading(value) {

    loading.classList.toggle(
        "hidden",
        !value
    );
}

// Save records
function saveToLocalStorage() {

    localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify(records)
    );
}

// Load records
function loadFromLocalStorage() {

    const savedRecords =
        localStorage.getItem(STORAGE_KEY);

    if (savedRecords) {

        try {

            records = JSON.parse(
                savedRecords
            );

        } catch (error) {

            console.error(
                "Failed to read saved records."
            );

            records = [];
        }
    }
}

// Get records
async function getRecords() {

    setLoading(true);

    hideStatus();

    try {

        const response =
            await fetch(API_URL);

        if (!response.ok) {

            throw new Error(
                `HTTP Error: ${response.status}`
            );
        }

        const data =
            await response.json();

        const apiRecords = data
            .filter(item => {

                return item.data &&
                    item.data.type === "ninja";

            })
            .map(item => {

                return {
                    id: item.id,
                    name: item.data.name,
                    email: item.data.email
                };

            });

        const savedRecords =
            JSON.parse(
                localStorage.getItem(
                    STORAGE_KEY
                ) || "[]"
            );

        const combinedRecords = [
            ...savedRecords
        ];

        apiRecords.forEach(apiRecord => {

            const exists =
                combinedRecords.some(
                    record =>
                        record.id === apiRecord.id
                );

            if (!exists) {

                combinedRecords.push(
                    apiRecord
                );
            }
        });

        records = combinedRecords;

        saveToLocalStorage();

        displayRecords();

    } catch (error) {

        console.error(error);

        loadFromLocalStorage();

        displayRecords();

        if (records.length > 0) {

            showStatus(
                "Using saved ninja records.",
                "success"
            );

        } else {

            showStatus(
                "Failed to load records.",
                "error"
            );
        }

    } finally {

        setLoading(false);
    }
}

// Display records
function displayRecords() {

    recordTable.innerHTML = "";

    if (records.length === 0) {

        recordTable.innerHTML = `
            <tr>
                <td colspan="4" class="no-records">
                    No ninja records found.
                </td>
            </tr>
        `;

        return;
    }

    records.forEach((record, index) => {

        const row =
            document.createElement("tr");

        row.innerHTML = `
            <td>${index + 1}</td>

            <td>
                ${record.name}
            </td>

            <td>
                ${record.email}
            </td>

            <td>

                <button
                    class="edit-btn"
                >
                    ✏️ Edit
                </button>

                <button
                    class="delete-btn"
                >
                    🗑️ Delete
                </button>

            </td>
        `;

        row.querySelector(
            ".edit-btn"
        ).addEventListener(
            "click",
            () => editRecord(record)
        );

        row.querySelector(
            ".delete-btn"
        ).addEventListener(
            "click",
            () => deleteRecord(record.id)
        );

        recordTable.appendChild(row);
    });
}

// Create record
async function createRecord(
    name,
    email
) {

    setLoading(true);

    hideStatus();

    try {

        const response =
            await fetch(API_URL, {

                method: "POST",

                headers: {
                    "Content-Type":
                        "application/json"
                },

                body: JSON.stringify({

                    name: name,

                    data: {
                        type: "ninja",
                        name: name,
                        email: email
                    }

                })
            });

        if (!response.ok) {

            throw new Error(
                `HTTP Error: ${response.status}`
            );
        }

        const newRecord =
            await response.json();

        records.push({

            id: newRecord.id,

            name: name,

            email: email

        });

        saveToLocalStorage();

        displayRecords();

        clearForm();

        showStatus(
            "Ninja added successfully!",
            "success"
        );

    } catch (error) {

        console.error(error);

        showStatus(
            "Failed to add ninja.",
            "error"
        );

    } finally {

        setLoading(false);
    }
}

// Update record
async function updateRecord(
    id,
    name,
    email
) {

    setLoading(true);

    hideStatus();

    try {

        const response =
            await fetch(
                `${API_URL}/${id}`,
                {

                    method: "PUT",

                    headers: {
                        "Content-Type":
                            "application/json"
                    },

                    body: JSON.stringify({

                        name: name,

                        data: {
                            type: "ninja",
                            name: name,
                            email: email
                        }

                    })
                }
            );

        if (!response.ok) {

            throw new Error(
                `HTTP Error: ${response.status}`
            );
        }

        const index =
            records.findIndex(
                record =>
                    record.id === id
            );

        if (index !== -1) {

            records[index] = {

                id: id,

                name: name,

                email: email
            };
        }

        saveToLocalStorage();

        displayRecords();

        showStatus(
            "Ninja updated successfully!",
            "success"
        );

    } catch (error) {

        console.error(error);

        showStatus(
            "Failed to update ninja.",
            "error"
        );

    } finally {

        setLoading(false);
    }
}

// Delete record
async function deleteRecord(id) {

    const confirmed =
        confirm(
            "Are you sure you want to delete this ninja?"
        );

    if (!confirmed) {

        return;
    }

    setLoading(true);

    hideStatus();

    try {

        const response =
            await fetch(
                `${API_URL}/${id}`,
                {
                    method: "DELETE"
                }
            );

        if (!response.ok) {

            throw new Error(
                `HTTP Error: ${response.status}`
            );
        }

        records =
            records.filter(
                record =>
                    record.id !== id
            );

        saveToLocalStorage();

        displayRecords();

        showStatus(
            "Ninja deleted successfully!",
            "success"
        );

    } catch (error) {

        console.error(error);

        showStatus(
            "Failed to delete ninja.",
            "error"
        );

    } finally {

        setLoading(false);
    }
}

// Open edit modal
function editRecord(record) {

    editId.value = record.id;

    editName.value = record.name;

    editEmail.value = record.email;

    editModal.classList.remove(
        "hidden"
    );

    editName.focus();
}

// Close edit modal
function closeEditModal() {

    editModal.classList.add(
        "hidden"
    );

    editForm.reset();
}

// Clear add form
function clearForm() {

    form.reset();

    recordId.value = "";

    saveBtn.textContent =
        "Add Ninja";

    cancelBtn.classList.add(
        "hidden"
    );
}

// Add form submit
form.addEventListener(
    "submit",
    async function(event) {

        event.preventDefault();

        const name =
            nameInput.value.trim();

        const email =
            emailInput.value.trim();

        if (!name || !email) {

            showStatus(
                "Please fill in all fields.",
                "error"
            );

            return;
        }

        await createRecord(
            name,
            email
        );
    }
);

// Edit form submit
editForm.addEventListener(
    "submit",
    async function(event) {

        event.preventDefault();

        const id =
            editId.value;

        const name =
            editName.value.trim();

        const email =
            editEmail.value.trim();

        if (!name || !email) {

            return;
        }

        await updateRecord(
            id,
            name,
            email
        );

        closeEditModal();
    }
);

// Cancel add form
cancelBtn.addEventListener(
    "click",
    function() {

        clearForm();

        hideStatus();
    }
);

// Close modal
closeModal.addEventListener(
    "click",
    function() {

        closeEditModal();
    }
);

// Cancel edit
cancelEdit.addEventListener(
    "click",
    function() {

        closeEditModal();
    }
);

// Click outside modal
editModal.addEventListener(
    "click",
    function(event) {

        if (event.target === editModal) {

            closeEditModal();
        }
    }
);

// Refresh records
refreshBtn.addEventListener(
    "click",
    async function() {

        await getRecords();
    }
);

// Load saved records first
loadFromLocalStorage();

displayRecords();

// Then get records from API
getRecords();